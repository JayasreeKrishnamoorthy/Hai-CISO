import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-operationalize',
  templateUrl: './operationalize.component.html',
  styleUrls: ['./operationalize.component.scss']
})
export class OperationalizeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
